<?php  
    // header("Access-Control-Allow-Origin: http://femex2.tk");
    header("Access-Control-Allow-Methods: GET,POST,OPTIONS,DELETE,PUT");
    // header("Access-Control-Allow-Headers: origin, x-requested-with, content-type, access-control-allow-origin");
?>